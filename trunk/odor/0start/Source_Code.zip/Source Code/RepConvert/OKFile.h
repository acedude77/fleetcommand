#pragma once

#include <windows.h>
#include <stdio.h>
#include <atlstr.h>

class OKFile  
{
public:
	OKFile();
	virtual ~OKFile();

	enum FileModes
	{
		FileMode_Read,		// Just Read, if file not exists, fail
		FileMode_ReadWrite, // Opens for read/write, must exist
		FileMode_Append,	// Opens file and sets file pointer to end
							// File must exist
		FileMode_ReCreate,	// Creates or resets a file

		FileMode_Text,		// Textmode
		FileMode_Binary		// Binarymode
	};

	bool Open  (CString a_fileName, int a_fileMode, int a_textOrBinary);
	void Close ();
	
	bool Write (const void* a_buffer, unsigned int a_size, 
		unsigned int a_count);
	bool Read  (void* a_buffer, unsigned int a_size, 
		unsigned int a_count);

	bool EndOfFile ();
	bool FlushFile ();

	bool ReadLine  (CString &a_string);

	bool ReadCharacter (char  &a_character);
	bool ReadInteger   (int   &a_integer);
	bool ReadFloat	   (float &a_float);
	bool ReadString	   (CString &a_string, int a_stringLenght);
	bool ReadDWORD	   (DWORD &a_dword);

	bool WriteCharacter (char  a_character);
	bool WriteInteger   (int   a_integer);
	bool WriteFloat	    (float a_float);
	bool WriteString	(CString a_string);
	bool WriteDWORD	    (DWORD a_dword);

	DWORD GetPosition ();
	bool SetPosition (DWORD a_position);
	bool SetPositionEnd ();

	// Write formated data
	bool WriteFormatedData (const char* a_format,...);

	//////////////////////////////////////////////////////////////////////
	// Some global file functions
	//////////////////////////////////////////////////////////////////////
	static bool DoesFileExist   (CString a_fileName);
	static bool CreateFile	    (CString a_fileName);
	static BOOL CreateDirectory (CString a_dirName);
	
	static DWORD GetFileSize	(CString a_fileName);
	
private:
	FILE*	m_file;
	bool	m_fileOpened;

};

