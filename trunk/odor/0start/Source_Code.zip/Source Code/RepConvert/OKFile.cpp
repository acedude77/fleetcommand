#pragma warning( disable : 4800 )

#include "stdafx.h"
#include "OKFile.h"

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

OKFile::OKFile()
{
	this->m_file = NULL;
	this->m_fileOpened = false;
}

OKFile::~OKFile()
{
	Close ();
}

//////////////////////////////////////////////////////////////////////
// Open File with given Filemodes
//////////////////////////////////////////////////////////////////////

bool OKFile::Open (CString a_fileName, int a_fileMode, int a_textOrBinary)
{
	char fileMode [5];

	switch (a_fileMode)
	{
	case FileModes::FileMode_Read:
		strcpy (fileMode,"r");
		break;

	case FileModes::FileMode_ReadWrite:
		strcpy (fileMode,"r+");
		break;

	case FileModes::FileMode_Append:
		strcpy (fileMode,"a");
		break;

	case FileModes::FileMode_ReCreate:
		strcpy (fileMode,"w+");
		break;

	default:
		strcpy (fileMode,"r");
		break;
	}

	if (a_textOrBinary == FileModes::FileMode_Text)
		strcat (fileMode,"t");
	else strcat (fileMode,"b");

	// If file is in use, close it
	if (m_fileOpened) Close();

	// Open the file, if fail return false
	m_file = fopen (a_fileName ,fileMode);
	if (m_file == NULL)
	{
		// Assert to info user
		return false;
	}

	// file successfully opened
	m_fileOpened = true;
	return true;
}

//////////////////////////////////////////////////////////////////////
// Close the file
//////////////////////////////////////////////////////////////////////

void OKFile::Close ()
{
	if (m_fileOpened) 
	{
		fclose (m_file);
	}

	m_fileOpened = false;
	m_file = NULL;
}

//////////////////////////////////////////////////////////////////////
// Write data to file
//////////////////////////////////////////////////////////////////////

bool OKFile::Write (const void* a_buffer, unsigned int a_size, 
		unsigned int a_count)
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	fwrite (a_buffer, a_size, a_count, m_file);
	return true;
}

//////////////////////////////////////////////////////////////////////
// Read data from File
//////////////////////////////////////////////////////////////////////

bool OKFile::Read (void* a_buffer, unsigned int a_size, 
		unsigned int a_count)
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	unsigned int count = fread (a_buffer, a_size, a_count, m_file);
	if (count != a_count)
		return false;

	return true;
}

//////////////////////////////////////////////////////////////////////
// Filecursor = End of File?
//////////////////////////////////////////////////////////////////////

bool OKFile::EndOfFile ()
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	if (feof (m_file) == 0) return false;
	else return true;
}

//////////////////////////////////////////////////////////////////////
// Flush File
//////////////////////////////////////////////////////////////////////

bool OKFile::FlushFile ()
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	if (fflush (m_file) == 0) return true;
	else return false;
}

//////////////////////////////////////////////////////////////////////
// Read a textline from a file
//////////////////////////////////////////////////////////////////////

bool OKFile::ReadLine (CString &a_line)
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	return ReadString (a_line,1024);
}


//////////////////////////////////////////////////////////////////////
// Read a single Character from file
//////////////////////////////////////////////////////////////////////

bool OKFile::ReadCharacter (char  &a_character)
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	return Read (&a_character,sizeof (char),1);
}

//////////////////////////////////////////////////////////////////////
// Read an integer from file
//////////////////////////////////////////////////////////////////////

bool OKFile::ReadInteger (int   &a_integer)
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	return Read (&a_integer,sizeof (int),1);
}

//////////////////////////////////////////////////////////////////////
// Read a float from file
//////////////////////////////////////////////////////////////////////

bool OKFile::ReadFloat (float &a_float)
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	return Read (&a_float,sizeof (float),1);
}

//////////////////////////////////////////////////////////////////////
// Read a string from file
//////////////////////////////////////////////////////////////////////

bool OKFile::ReadString (CString &a_string, int a_stringLenght)
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	char buffer [2048];
	fgets (buffer,a_stringLenght,m_file);

	a_string = buffer;
	return true;
}

//////////////////////////////////////////////////////////////////////
// Read DWORD from file
//////////////////////////////////////////////////////////////////////

bool OKFile::ReadDWORD (DWORD &a_dword)
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	return Read (&a_dword,sizeof (DWORD),1);
}

//////////////////////////////////////////////////////////////////////
// Write a character to file
//////////////////////////////////////////////////////////////////////

bool OKFile::WriteCharacter (char  a_character)
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	return Write (&a_character,sizeof (char),1);
}

//////////////////////////////////////////////////////////////////////
// Write an integer to file
//////////////////////////////////////////////////////////////////////

bool OKFile::WriteInteger (int   a_integer)
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	return Write (&a_integer,sizeof (int),1);
}

//////////////////////////////////////////////////////////////////////
// Write float to file
//////////////////////////////////////////////////////////////////////

bool OKFile::WriteFloat (float a_float)
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	return Write (&a_float,sizeof (float),1);
}

//////////////////////////////////////////////////////////////////////
// Write String to file
//////////////////////////////////////////////////////////////////////

bool OKFile::WriteString (CString a_string)
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	return WriteFormatedData ("%s",a_string);
}

//////////////////////////////////////////////////////////////////////
// Write a dword to file
//////////////////////////////////////////////////////////////////////

bool OKFile::WriteDWORD (DWORD a_dword)
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	return Write (&a_dword,sizeof (DWORD),1);
}

//////////////////////////////////////////////////////////////////////
// Get current position in file
//////////////////////////////////////////////////////////////////////

DWORD OKFile::GetPosition ()
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	return ftell (m_file);
}

//////////////////////////////////////////////////////////////////////
// Set Position of file
//////////////////////////////////////////////////////////////////////

bool OKFile::SetPosition (DWORD a_position)
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	if (fseek (m_file,a_position,SEEK_SET) != 0) return false;
	return true;
}

//////////////////////////////////////////////////////////////////////
// Set pointer to eof position
//////////////////////////////////////////////////////////////////////

bool OKFile::SetPositionEnd ()
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	if (fseek (m_file,0,SEEK_END) != 0) return false;
	return true;
}

//////////////////////////////////////////////////////////////////////
// Write formated data to file
//////////////////////////////////////////////////////////////////////

bool OKFile::WriteFormatedData (const char* a_format,...)
{
	if (!m_fileOpened) 
	{
		//Assert to info user
		return false;
	}

	va_list  argptr;
	va_start (argptr, a_format);

	if (vfprintf (m_file, a_format, argptr) < 0)
	{
		va_end (argptr);
		return false;
	}

	va_end (argptr);
	FlushFile();
	return true;
} 

//////////////////////////////////////////////////////////////////////
// Now Some global file functions
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
// Check if file exists
//////////////////////////////////////////////////////////////////////

bool OKFile::DoesFileExist (CString a_fileName)
{
	DWORD dwAttr = GetFileAttributes(a_fileName);
    if (dwAttr == (DWORD) -1) return false;
	else return true;
}

//////////////////////////////////////////////////////////////////////
// Create a file and close it, so just that it exists
//////////////////////////////////////////////////////////////////////

bool OKFile::CreateFile (CString a_fileName)
{
	FILE* file = NULL;

	file = fopen (a_fileName,"w+");
	
	if (file == NULL) return false;
	
	fclose (file);
	return true;
}

//////////////////////////////////////////////////////////////////////
// Create a directory
//////////////////////////////////////////////////////////////////////

BOOL OKFile::CreateDirectory (CString a_dirName)
{
	return ::CreateDirectory (a_dirName,NULL);
}

//////////////////////////////////////////////////////////////////////
// Get size of a file
//////////////////////////////////////////////////////////////////////

DWORD OKFile::GetFileSize (CString a_fileName)
{
	FILE* file = NULL;
	DWORD size = 0;

	file = fopen (a_fileName,"r");
	if (file == NULL) return -1;

	fseek (file,0,SEEK_END);
	size = ftell (file);
	
	fclose (file);
	return size;
}